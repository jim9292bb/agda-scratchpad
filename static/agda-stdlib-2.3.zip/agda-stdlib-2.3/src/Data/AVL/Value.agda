------------------------------------------------------------------------
-- The Agda standard library
--
-- This module is DEPRECATED.
------------------------------------------------------------------------

{-# OPTIONS --cubical-compatible --safe #-}

open import Relation.Binary.Bundles using (Setoid)

module Data.AVL.Value {a ℓ} (S : Setoid a ℓ) where

{-# WARNING_ON_IMPORT
"Data.AVL.Value was deprecated in v1.4.
Use Data.Tree.AVL.Value instead."
#-}

open import Data.Tree.AVL.Value S public
